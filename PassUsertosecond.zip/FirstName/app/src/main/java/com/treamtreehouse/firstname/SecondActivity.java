package com.treamtreehouse.firstname;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.w3c.dom.Text;

public class SecondActivity extends AppCompatActivity {
private static final String TAG = "SecondActivity";
private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_second );

        textView = findViewById(R.id.textView);
        Intent intent = getIntent ();

       {
            StringBuilder sb = new StringBuilder( );
            User user   = (User) intent.getSerializableExtra ( Constants.KEY_2 );
            sb.append ( user.getFirstname ());
            sb.append ( " " );

            sb.append ( user.getMiddlename ());
            sb.append ( " " );

            sb.append ( user.getLastname () );
            sb.append ( " " );

            textView.setText(sb.toString ());
            Log.d ( TAG, "User: "+sb.toString ());

        }
        Log.d ( TAG , "onCreate: " );

    }

    @Override
    protected void onStart() {
        super.onStart ();
        Log.d ( TAG , "onStart: " );
    }

    @Override
    protected void onResume() {
        super.onResume ();
        Log.d ( TAG , "onResume: " );
    }

    @Override
    protected void onPause() {
        super.onPause ();
        Log.d ( TAG , "onPause: " );
    }

    @Override
    protected void onStop() {
        super.onStop ();
        Log.d ( TAG , "onStop: " );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy ();
        Log.d ( TAG , "onDestroy: " );
    }
}

